<?php

namespace IPS\nehidecontent;

/* To prevent PHP errors (extending class does not exist) revealing path */
if (!\defined('\IPS\SUITE_UNIQUE_KEY')) {
    header(( isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden');
    exit;
}

class _CheckStuff {

    public function blah() {
        
    }

    public static function checkApp($item = NULL) {
        if (static::oldPluginEnabled()) {
            return false;
        }
        if (\is_null($item)) {
            return false;
        }
        if (\IPS\Request::i()->isAjax()) {
            if (!\IPS\Request::i()->preview) {
                if (isset(\IPS\Request::i()->do) AND \IPS\Request::i()->do !== '') {
                    $doCheck = array(
                        'embed',
                        'checkForNewReplies'
                    );
                    if (!\in_array(\IPS\Request::i()->do, $doCheck)) {
                        return false;
                    }
                    if (\IPS\Request::i()->do == 'checkForNewReplies') {
                        if (ISSET(\IPS\Request::i()->type) AND (\IPS\Request::i()->type !== 'fetch' AND \IPS\Request::i()->type !== 'count')) {
                            return false;
                        }
                    }
                }
            }
        }
        if (\IPS\Session::i()->userAgent->spider AND!\IPS\Settings::i()->neapp_hidecontent_searchengine) {
            return true;
        }
        //Do stuff
        switch (\IPS\Request::i()->app) {
            case 'forums':
                $containerId = $item->container()->_id;
                $itemId = $item->topic_id;
                $authorId = $item->author_id;
                break;
            case 'cms':
                $containerId = $item->container()->database_id;
                $itemId = null;
                if (isset($item->member_id)) {
                    $authorId = $item->member_id; //record
                } elseif (isset($item->user)) {
                    $authorId = $item->user; //comment
                } elseif (isset($item->author)) {
                    $authorId = $item->author; //review
                }
                break;
            case 'calendar':
                $authorId = $item->member_id;
                $containerId = $item->container()->_id;
                $itemId = null;
                break;
        }
        return static::checkItem(\IPS\Request::i()->app, \get_class($item), $containerId, $itemId, $authorId);
    }

    public static function checkSearch($data) {
        if (static::oldPluginEnabled()) {
            return false;
        }
        if (\IPS\Session::i()->userAgent->spider AND \IPS\Settings::i()->neapp_hidecontent_searchengine) {
            return false;
        }
        if (\is_null($data)) {
            return false;
        }
        //Do stuff
        if (\IPS\Settings::i()->neapp_hidecontent_hide_where_search AND ( \IPS\Settings::i()->neapp_hidecontent_hidesearch_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hidesearch_groups)))) {
            if (!\function_exists('str_starts_with')) {
                if (mb_strpos($data['index_class'], 'IPS\cms', 0) !== FALSE) {
                    $app = 'cms';
                }
                if (mb_strpos($data['index_class'], 'IPS\forums', 0) !== FALSE) {
                    $app = 'forums';
                }
                if (mb_strpos($data['index_class'], 'IPS\calendar', 0) !== FALSE) {
                    $app = 'calendar';
                }
            } else {
                if (str_starts_with($data['index_class'], 'IPS\cms')) {
                    $app = 'cms';
                }
                if (str_starts_with($data['index_class'], 'IPS\forums')) {
                    $app = 'forums';
                }
                if (str_starts_with($data['index_class'], 'IPS\calendar')) {
                    $app = 'calendar';
                }
            }
            return static::checkItem($app, $data['index_class'], $data['index_container_id'], $data['index_item_id']);
        }
        return false;
    }

    protected static function checkItem($app, $itemClass, $containerId, $itemId, $authorId = NULL) {
        switch ($app) {
            case 'forums':
                if (\IPS\Settings::i()->neapp_hidecontent_hide_where_forums) {
                    if (\IPS\Request::i()->do !== 'edit' AND!\IPS\Session::i()->userAgent->spider) {
                        if (!\in_array($itemId, explode(",", \IPS\Settings::i()->neapp_hidecontent_exclude_topics))) {
                            if (!\IPS\Settings::i()->neapp_hidecontent_forum_type) { //Include forums
                                if (\IPS\Settings::i()->neapp_hidecontent_include_forums === '0' OR \in_array($containerId, explode(",", \IPS\Settings::i()->neapp_hidecontent_include_forums))) {
                                    return true;
                                }
                            } else { //Exclude forums
                                if (\IPS\Settings::i()->neapp_hidecontent_exclude_forums !== '0' AND!\in_array($containerId, explode(",", \IPS\Settings::i()->neapp_hidecontent_exclude_forums))) {
                                    return true;
                                }
                            }
                        }
                    }
                }
                return false;
            case 'cms':
                if (\IPS\Settings::i()->neapp_hidecontent_hide_where_cms) {
                    if (\IPS\Request::i()->do !== 'edit' AND!\IPS\Session::i()->userAgent->spider) {
                        if (!\function_exists('str_starts_with')) {
                            if (mb_substr($itemClass, 0, mb_strlen('IPS\cms\Records')) === 'IPS\cms\Records') {
                                $type = 'Record';
                            }
                            if (mb_substr($itemClass, 0, mb_strlen('IPS\cms\Records\Comment')) === 'IPS\cms\Records\Comment') {
                                $type = 'Comment';
                            }
                            if (mb_substr($itemClass, 0, mb_strlen('IPS\cms\Records\Review')) === 'IPS\cms\Records\Review') {
                                $type = 'Review';
                            }
                        } else {
                            if (str_starts_with($itemClass, 'IPS\cms\Records')) {
                                $type = 'Record';
                            }
                            if (str_starts_with($itemClass, 'IPS\cms\Records\Comment')) {
                                $type = 'Comment';
                            }
                            if (str_starts_with($itemClass, 'IPS\cms\Records\Review')) {
                                $type = 'Review';
                            }
                        }
                        switch ($type) {
                            case 'Record':
                                if (\IPS\Settings::i()->neapp_hidecontent_cms_databases_enabled) {
                                    if (\IPS\Settings::i()->neapp_hidecontent_cms_databases === '0' OR \in_array($containerId, explode(",", \IPS\Settings::i()->neapp_hidecontent_cms_databases))) {
                                        return true;
                                    }
                                }
                                break;
                            case 'Comment';
                                if (\IPS\Settings::i()->neapp_hidecontent_cms_comments_enabled) {
                                    if (\IPS\Settings::i()->neapp_hidecontent_cms_comments_databases === '0' OR \in_array($containerId, explode(",", \IPS\Settings::i()->neapp_hidecontent_cms_comments_databases))) {
                                        return true;
                                    }
                                }
                                break;
                            case 'Review';
                                if (\IPS\Settings::i()->neapp_hidecontent_cms_reviews_enabled) {
                                    if (\IPS\Settings::i()->neapp_hidecontent_cms_reviews_databases === '0' OR \in_array($containerId, explode(",", \IPS\Settings::i()->neapp_hidecontent_cms_reviews_databases))) {
                                        return true;
                                    }
                                }
                                break;
                        }
                    }
                }
                return false;
            case 'calendar':
                if (\IPS\Settings::i()->neapp_hidecontent_hide_where_calendar) {
                    if (\IPS\Request::i()->do !== 'edit' AND!\IPS\Session::i()->userAgent->spider) {
                        //Check if it is an event/comment/review
                        switch ($itemClass) {
                            case 'IPS\calendar\Event':
                                if (\IPS\Settings::i()->neapp_hidecontent_calendar_event) {
                                    if (\IPS\Settings::i()->neapp_hidecontent_calendar_calendars_events === '0' OR \in_array($containerId, explode(",", \IPS\Settings::i()->neapp_hidecontent_calendar_calendars_events))) {
                                        return true;
                                    }
                                }
                                break;
                            case 'IPS\calendar\Event\Comment';
                                if (\IPS\Settings::i()->neapp_hidecontent_calendar_comments) {
                                    if (\IPS\Settings::i()->neapp_hidecontent_calendar_calendars_comments === '0' OR \in_array($containerId, explode(",", \IPS\Settings::i()->neapp_hidecontent_calendar_calendars_comments))) {
                                        return true;
                                    }
                                }
                                break;
                            case 'IPS\calendar\Event\Review';
                                if (\IPS\Settings::i()->neapp_hidecontent_calendar_reviews) {
                                    if (\IPS\Settings::i()->neapp_hidecontent_calendar_calendars_reviews === '0' OR \in_array($containerId, explode(",", \IPS\Settings::i()->neapp_hidecontent_calendar_calendars_reviews))) {
                                        return true;
                                    }
                                }
                                break;
                        }
                    }
                }
                return false;
            default:
                return false;
        }
    }

    public static function checkTag($tag) {
        $array = array();
        switch ($tag) {
            case 'image':
                $array['query'] = "//img[contains(@class,'ipsImage')] | //a[contains(@class,'ipsAttachLink_image')]";
                if (\IPS\Settings::i()->neapp_hidecontent_hideemoticons) {
                    $array['query'] = "//img[contains(@class,'ipsImage') or @data-emoticon] | //span[contains(@class,'ipsEmoji')] | //a[contains(@class,'ipsAttachLink_image')]";
                }
                $array['type'] = \IPS\Settings::i()->neapp_hidecontent_hideimages_messagetype;
                $array['message'] = \IPS\Member::loggedIn()->language()->addToStack("neapp_hidecontent_hideimages_text_value");
                break;
            case 'spoiler':
                $array['query'] = "//div[@class='ipsSpoiler']";
                $array['type'] = \IPS\Settings::i()->neapp_hidecontent_hidespoilers_messagetype;
                $array['message'] = \IPS\Member::loggedIn()->language()->addToStack("neapp_hidecontent_hidespoilers_text_value");
                break;
            case 'video':
                $array['query'] = "//video";
                $array['type'] = \IPS\Settings::i()->neapp_hidecontent_hidevideos_messagetype;
                $array['message'] = \IPS\Member::loggedIn()->language()->addToStack("neapp_hidecontent_hidevideos_text_value");
                break;
            case 'audio':
                $array['query'] = "//audio";
                $array['type'] = \IPS\Settings::i()->neapp_hidecontent_hideaudio_messagetype;
                $array['message'] = \IPS\Member::loggedIn()->language()->addToStack("neapp_hidecontent_hideaudio_text_value");
                break;
            case 'code':
                $array['query'] = "//pre";
                $array['type'] = \IPS\Settings::i()->neapp_hidecontent_hidecode_messagetype;
                $array['message'] = \IPS\Member::loggedIn()->language()->addToStack("neapp_hidecontent_hidecode_text_value");
                break;
            case 'quote':
                $array['query'] = "//blockquote";
                $array['type'] = \IPS\Settings::i()->neapp_hidecontent_hidequotes_messagetype;
                $array['message'] = \IPS\Member::loggedIn()->language()->addToStack("neapp_hidecontent_hidequotes_text_value");
                break;
            case 'attachment':
                $array['query'] = "//a[@rel='' and contains(@class,'ipsAttachLink') and not(contains(@class,'ipsAttachLink_image'))]";
                $array['type'] = \IPS\Settings::i()->neapp_hidecontent_hideattachments_messagetype;
                $array['message'] = \IPS\Member::loggedIn()->language()->addToStack("neapp_hidecontent_hideattachments_text_value");
                break;
            case 'link':
                //Build the query based on the chosen settings
                $temp = array();
                if (\IPS\Settings::i()->neapp_hidecontent_hidelinks_external) {
                    if (\IPS\Settings::i()->neapp_hidecontent_hidelinks_external_nofollow) {
                        $temp[] = "//a[contains(@rel,'external') and contains(@rel,'nofollow')]";
                    } else {
                        $temp[] = "//a[contains(@rel,'external')]";
                    }
                }
                if (\IPS\Settings::i()->neapp_hidecontent_hidelinks_internal) {
                    $temp[] = "//a[@rel='' and not(contains(@class,'ipsAttachLink')) and not(@data-mentionid)]";
                    if (\IPS\Settings::i()->neapp_hidecontent_hidelinks_internal_embeds) {
                        $temp[] = "//iframe[@data-embedauthorid]";
                    }
                }
                if (\IPS\Settings::i()->neapp_hidecontent_hidementions) {
                    $temp[] = "//a[@rel='' and @data-mentionid]";
                }
                if (!empty($temp)) {
                    $array['query'] = implode(' | ', $temp);
                }
                $array['type'] = \IPS\Settings::i()->neapp_hidecontent_hidelinks_messagetype;
                $array['message'] = \IPS\Member::loggedIn()->language()->addToStack("neapp_hidecontent_hidelinks_text_value");
                break;
            case 'imageinquote':
                $array['query'] = "//blockquote//img";
                break;
            case 'imageinlightbox':
                $array['query'] = "//img[contains(@class,'ipsImage_thumbnailed')]";
                break;
        }
        return $array;
    }

    public static function oldPluginEnabled() {
        $plugins = \IPS\Plugin::enabledPlugins();
        foreach (\IPS\Plugin::enabledPlugins() as $k => $v) {
            if ($v->name == '(NE) Hide content') {
                return true;
                break;
            }
        }
        return false;
    }

    public static function htmlPlayerAppEnabled() {
        if (\in_array('neapphtmlplayer', array_keys(\IPS\Application::applications())) AND \IPS\Application::appIsEnabled('neapphtmlplayer')) {
            $results = array();
            $results['enabled'] = true;
            foreach (\IPS\Application::applications() as $key => $app) {
                if ($key === 'nehidecontent') {
                    $nehidecontentpos = $app->position;
                }
                if ($key === 'neapphtmlplayer') {
                    $neapphtmlplayerpos = $app->position;
                }
            }
            if ($nehidecontentpos > $neapphtmlplayerpos) {
                $results['position'] = true;
            } else {
                $results['position'] = false;
            }
            return $results;
        } else {
            return array('enabled' => false);
        }
    }

}
