<?php

namespace IPS\nehidecontent;

/* To prevent PHP errors (extending class does not exist) revealing path */
if (!\defined('\IPS\SUITE_UNIQUE_KEY')) {
    header(( isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden');
    exit;
}

class _ProcessStuff {

    public function blah() {
        
    }

    public static function processContent($content, $tags = true) {
        if (!$tags) { //False has been sent in, so it's going to be "Hide all content"
            if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent_skeleton_enabled) {
                if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent_skeleton_include) {
                    $message = \IPS\Member::loggedIn()->language()->addToStack("neapp_hidecontent_hideallcontent_text_value");
                } else {
                    $message = '';
                }
                $content = \IPS\Theme::i()->getTemplate('hide', 'nehidecontent', 'front')->hideAllContent_skeleton($message);
            } else {
                if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent_messagetype_enabled) {
                    $content = \IPS\Theme::i()->getTemplate('hide', 'nehidecontent', 'front')->hideAllContent_messageType(\IPS\Member::loggedIn()->language()->addToStack("neapp_hidecontent_hideallcontent_text_value"), \IPS\Settings::i()->neapp_hidecontent_hideallcontent_messagetype);
                } else {
                    $content = \IPS\Member::loggedIn()->language()->addToStack("neapp_hidecontent_hideallcontent_text_value");
                }
            }
            if (static::checkMetaDescription()) {
                \IPS\member::loggedIn()->language()->parseOutputForDisplay($content);
            }
            return $content;
        }
        //If we are here, then it's because "hide all content" isn't the configured setting
        $source = new \IPS\Xml\DOMDocument('1.0', 'UTF-8');
        $source->loadHTML(\IPS\Xml\DOMDocument::wrapHtml($content));
        //Let's do stuff...
        $xpath = new \DOMXPath($source);
        if (\IPS\Settings::i()->neapp_hidecontent_hideimages AND ( \IPS\Settings::i()->neapp_hidecontent_hideimages_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hideimages_groups)))) {
            static::processTag($source, 'image');
        }
        if (\IPS\Settings::i()->neapp_hidecontent_hidespoilers AND ( \IPS\Settings::i()->neapp_hidecontent_hidespoilers_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hidespoilers_groups)))) {
            static::processTag($source, 'spoiler');
        }
        if (\IPS\Settings::i()->neapp_hidecontent_hidevideos AND ( \IPS\Settings::i()->neapp_hidecontent_hidevideos_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hidevideos_groups)))) {
            static::processTag($source, 'video');
        }
        if (\IPS\Settings::i()->neapp_hidecontent_hideaudio AND ( \IPS\Settings::i()->neapp_hidecontent_hideaudio_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hideaudio_groups)))) {
            static::processTag($source, 'audio');
        }
        if (\IPS\Settings::i()->neapp_hidecontent_hidelinks AND ( \IPS\Settings::i()->neapp_hidecontent_hidelinks_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hidelinks_groups)))) {
            static::processTag($source, 'link');
        }
        if (\IPS\Settings::i()->neapp_hidecontent_hidecode AND ( \IPS\Settings::i()->neapp_hidecontent_hidecode_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hidecode_groups)))) {
            static::processTag($source, 'code');
        }
        if (\IPS\Settings::i()->neapp_hidecontent_hidequotes AND ( \IPS\Settings::i()->neapp_hidecontent_hidequotes_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hidequotes_groups)))) {
            static::processTag($source, 'quote');
        }
        if (\IPS\Settings::i()->neapp_hidecontent_hideattachments AND ( \IPS\Settings::i()->neapp_hidecontent_hideattachments_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hideattachments_groups)))) {
            static::processTag($source, 'attachment');
        }
        if (\IPS\Settings::i()->neapp_hidecontent_imagesinquotes) {
            static::processImagesInQuotes($source);
        }
        if (\is_null(\IPS\Member::loggedIn()->member_id) AND \IPS\Settings::i()->neapp_hidecontent_hideimages_disablelightbox) {
            static::processImagesInLightbox($source);
        }
        //Finished doing stuff
        $content = preg_replace('/^<!DOCTYPE.+?>/', '', str_replace(array('<html>', '</html>', '<head>', '</head>', '<body>', '</body>', '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">'), '', $source->saveHTML()));
        $content = static::fixStuff($content);
        if (static::CheckMetaDescription()) {
            \IPS\member::loggedIn()->language()->parseOutputForDisplay($content);
        }
        return $content;
    }

    protected static function processTag($source, $tag) {
        $xpath = new \DOMXPath($source);
        $banana = \IPS\nehidecontent\CheckStuff::checkTag($tag);
        $test = $xpath->evaluate($banana['query']);
        if ($test->length) {
            $substitute = static::replaceStuff($source, $banana['message'], $banana['type']);
            foreach ($xpath->evaluate($banana['query']) as $i => $item) {
                if (\IPS\Settings::i()->neapp_hidecontent_mergehidemessages) {
                    if ($i === 0) {
                        $item->parentNode->replaceChild($substitute, $item);
                    } else {
                        $item->parentNode->removeChild($item);
                    }
                } else {
                    $item->parentNode->replaceChild($substitute->cloneNode(TRUE), $item);
                }
            }
        }
    }

    protected static function checkMetaDescription() {
        //Little check to see if this request is coming in from the $item->metaDescription() call
        $neBackTrace = debug_backtrace(0);
        foreach ($neBackTrace as $k => $v) {
            if (isset($v['function']) && $v['function'] == 'metaDescription') {
                return true;
            }
        }
        return false;
    }

    protected static function processImagesInQuotes($source) {
        $xpath = new \DOMXPath($source);
        $banana = \IPS\nehidecontent\CheckStuff::checkTag('imageinquote');
        $test = $xpath->evaluate($banana['query']);
        if ($test->length) {
            foreach ($xpath->evaluate($banana['query']) as $i => $item) {
                if (!$item->hasAttribute('data-emoticon')) {
                    if (!empty($item->parentNode->tagName)) {
                        if ($item->parentNode->tagName === 'a') {
                            $item->parentNode->removeAttribute('class');
                            $item->parentNode->removeAttribute('data-fileid');
                        } else {
                            
                        }
                    }
                }
            }
        }
    }

    protected static function processImagesInLightbox($source) {
        $xpath = new \DOMXPath($source);
        $banana = \IPS\nehidecontent\CheckStuff::checkTag('imageinlightbox');
        $test = $xpath->evaluate($banana['query']);
        if ($test->length) {
            foreach ($xpath->evaluate($banana['query']) as $i => $item) {
                if ($item->parentNode->tagName === 'a') {
                    if (\IPS\Settings::i()->neapp_hidecontent_hideimages_disablelightbox_login) {
                        $item->parentNode->setAttribute('href', \IPS\Http\Url::internal('login'));
                        $item->parentNode->setAttribute('data-ipsdialog', '');
                        $item->parentNode->setAttribute('data-ipsdialog-url', \IPS\Http\Url::internal('login'));
                        $item->parentNode->setAttribute('data-ipsdialog-modal', 'true');
                        $item->parentNode->setAttribute('data-ipsdialog-title', \IPS\Member::loggedIn()->language()->addToStack("app_sign_in"));
                    } else {
                        //Display thumb instead
                        $thumb = $item->getAttribute('data-src');
                        $item->parentNode->setAttribute('href', $thumb);
                    }
                }
            }
        }
    }

    protected static function replaceStuff($source, $message, $type) {
        $test = \IPS\Theme::i()->getTemplate('hide', 'nehidecontent', 'front')->hideContent_tags($message);
        $substitute = $source->createElement('div', $test);
        $substitute->setattribute('class', 'ipsMessage ipsMessage_' . $type . ' nehidecontent');
        return $substitute;
    }

    protected static function fixStuff($content) {
        //Some little fixes to remove/modify the resulting content.
        //An issue where some emoticons won't display due to the DOM conversion process
        $content = str_replace('&lt;fileStore.core_Emoticons&gt;', '<fileStore.core_Emoticons>', $content);
        //An issue where attachments won't display due to the DOM conversion process
        $content = str_replace('&lt;fileStore.core_Attachment&gt;', '<fileStore.core_Attachment>', $content);
        //An issue where gallery images won't display due to the DOM conversion process
        $content = str_replace('&lt;fileStore.gallery_Images&gt;', '<fileStore.gallery_Images>', $content);
        //An issue where links won't display due to the DOM conversion process
        $content = str_replace('&lt;___base_url___&gt;', '<___base_url___>', $content);
        $content = str_replace('<?xml encoding="utf-8" ?>', '', $content);
        return $content;
    }

}
