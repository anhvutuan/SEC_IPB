<?php
/**
 * @brief		POC - (NE) Hide Content on steroids Application Class
 * @author		<a href='https://invisioncommunity.com/profile/35662-nathan-explosion/'>Nathan Explosion</a>
 * @copyright	(c) 2022 Nathan Explosion
 * @package		Invision Community
 * @subpackage	POC - (NE) Hide Content on steroids
 * @since		07 May 2022
 * @version		
 */
 
namespace IPS\nehidecontent;

/**
 * POC - (NE) Hide Content on steroids Application Class
 */
class _Application extends \IPS\Application
{
	protected function get__icon() {
        return 'bomb';
    }

    public function installOther() {
        $pluginData = \IPS\Db::i()->select('count(*)', 'core_plugins', array('plugin_location=?', "nehidecontent"))->first();
        if ($pluginData > 0) {
            try {
                //Convert settings from plugin version
                //List of settings from old plugin, with their application equivalent
                $settings = array(
                    //'plugin_setting' => 'application_setting',
                    'nehideposts_forums' => 'neapp_hidecontent_include_forums',
                    'nehideposts_exclude_forums' => 'neapp_hidecontent_exclude_forums',
                    'nehideposts_excludetopics' => 'neapp_hidecontent_exclude_topics',
                    'nehideposts_includefirstpost' => 'neapp_hidecontent_includefirstpost',
                    'nehideposts_hideallcontent' => 'neapp_hidecontent_hideallcontent',
                    'nehideposts_hideallcontent_groups' => 'neapp_hidecontent_hideallcontent_groups',
                    'nehideposts_hidelinks' => 'neapp_hidecontent_hidelinks',
                    'nehideposts_hidelinks_groups' => 'neapp_hidecontent_hidelinks_groups',
                    'nehideposts_hidelinks_external' => 'neapp_hidecontent_hidelinks_external',
                    'nehideposts_hidelinks_internal' => 'neapp_hidecontent_hidelinks_internal',
                    'nehideposts_hidelinks_internal_embeds' => 'neapp_hidecontent_hidelinks_internal_embeds',
                    'nehideposts_hidelinks_external_nofollow' => 'neapp_hidecontent_hidelinks_external_nofollow',
                    'nehideposts_hideimages' => 'neapp_hidecontent_hideimages',
                    'nehideposts_hideimages_groups' => 'neapp_hidecontent_hideimages_groups',
                    'nehideposts_hideemoticons' => 'neapp_hidecontent_hideemoticons',
                    'nehideposts_hidementions' => 'neapp_hidecontent_hidementions',
                    'nehideposts_hideattachments' => 'neapp_hidecontent_hideattachments',
                    'nehideposts_hideattachments_groups' => 'neapp_hidecontent_hideattachments_groups',
                    'nehideposts_hidecode' => 'neapp_hidecontent_hidecode',
                    'nehideposts_hidecode_groups' => 'neapp_hidecontent_hidecode_groups',
                    'nehideposts_hidespoilers' => 'neapp_hidecontent_hidespoilers',
                    'nehideposts_hidespoilers_groups' => 'neapp_hidecontent_hidespoilers_groups',
                    'nehideposts_hidequotes' => 'neapp_hidecontent_hidequotes',
                    'nehideposts_hidequotes_groups' => 'neapp_hidecontent_hidequotes_groups',
                    'nehideposts_hidevideos' => 'neapp_hidecontent_hidevideos',
                    'nehideposts_hidevideos_groups' => 'neapp_hidecontent_hidevideos_groups',
                    'nehideposts_mergehidemessages' => 'neapp_hidecontent_mergehidemessages',
                    'nehideposts_searchengine' => 'neapp_hidecontent_searchengine',
                    'nehideposts_databases' => 'neapp_hidecontent_cms_databases',
                    'nehideposts_databases_enabled' => 'neapp_hidecontent_cms_databases_enabled',
                    'nehideposts_cms_comments_enabled' => 'neapp_hidecontent_cms_comments_enabled',
                    'nehideposts_cms_comments_databases' => 'neapp_hidecontent_cms_comments_databases',
                    'nehideposts_imagesinquotes' => 'neapp_hidecontent_imagesinquotes',
                    'nehideposts_forum_type' => 'neapp_hidecontent_forum_type',
                );
                foreach ($settings as $k => $v) {
                    \IPS\Settings::i()->changeValues(array($v => \IPS\Settings::i()->$k));
                }
                //Special to enable/disable some setting that are new to the application
                \IPS\Settings::i()->changeValues(array('neapp_hidecontent_hide_where_forums' => true));
                if (\IPS\Settings::i()->nehideposts_databases_enabled OR \IPS\Settings::i()->nehideposts_cms_comments_enabled) {
                    \IPS\Settings::i()->changeValues(array('neapp_hidecontent_hide_where_cms' => true));
                }
                if (\IPS\Settings::i()->nehideposts_hidevideos) {
                    \IPS\Settings::i()->changeValues(array('neapp_hidecontent_hidevideos_internal' => true));
                    \IPS\Settings::i()->changeValues(array('neapp_hidecontent_hidevideos_external' => true));
                }
                //Convert language strings, if possible.
                //List of translatables from old plugin, with their application equivalent
                $translatables = array(
                    'nehideposts_hidecontent_translatable' => 'neapp_hidecontent_hideallcontent_text_value',
                    'nehideposts_hideattachments_translatable' => 'neapp_hidecontent_hideattachments_text_value',
                    'nehideposts_hidecode_translatable' => 'neapp_hidecontent_hidecode_text_value',
                    'nehideposts_hideimages_translatable' => 'neapp_hidecontent_hideimages_text_value',
                    'nehideposts_hidelinks_translatable' => 'neapp_hidecontent_hidelinks_text_value',
                    'nehideposts_hidequotes_translatable' => 'neapp_hidecontent_hidequotes_text_value',
                    'nehideposts_hidespoilers_translatable' => 'neapp_hidecontent_hidespoilers_text_value',
                    'nehideposts_hidevideos_translatable' => 'neapp_hidecontent_hidevideos_text_value'
                );
                foreach ($translatables as $k => $v) {
                    \IPS\Lang::copyCustom('core', $k, $v, 'nehidecontent');
                    \IPS\Lang::deleteCustom('core', $k);
                }
                //Delete plugin version
                \IPS\Application::load('nehidecontent')->enabled = 1;
                \IPS\Application::load('nehidecontent')->save();
                \IPS\Task::queue('nehidecontent', 'DeleteNePluginHideContent', array(), 1);
            } catch (\UnderflowException $e) {
                
            }
        }
    }
}