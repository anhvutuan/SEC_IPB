<?php

/**
 * @brief		Background Task
 * @author		<a href='https://www.invisioncommunity.com'>Invision Power Services, Inc.</a>
 * @copyright	(c) Invision Power Services, Inc.
 * @license		https://www.invisioncommunity.com/legal/standards/
 * @package		Invision Community
 * @subpackage	POC - (NE) Hide Content on steroids
 * @since		09 May 2022
 */

namespace IPS\nehidecontent\extensions\core\Queue;

/* To prevent PHP errors (extending class does not exist) revealing path */
if (!\defined('\IPS\SUITE_UNIQUE_KEY')) {
    header(( isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden');
    exit;
}

/**
 * Background Task
 */
class _DeleteNePluginHideContent {

    /**
     * Parse data before queuing
     *
     * @param	array	$data
     * @return	array
     */
    public function preQueueData($data) {
        return $data;
    }

    /**
     * Run Background Task
     *
     * @param	mixed						$data	Data as it was passed to \IPS\Task::queue()
     * @param	int							$offset	Offset
     * @return	int							New offset
     * @throws	\IPS\Task\Queue\OutOfRangeException	Indicates offset doesn't exist and thus task is complete
     */
    public function run($data, $offset) {
        //This will remove the plugin version of the application
        $pluginData = \IPS\Db::i()->select('*', 'core_plugins', array('plugin_location=?', "nehidecontent"))->first();
        $plugin = \IPS\Plugin::load($pluginData['plugin_id']);
        $plugin->delete();
        throw new \IPS\Task\Queue\OutOfRangeException;
    }

    /**
     * Get Progress
     *
     * @param	mixed					$data	Data as it was passed to \IPS\Task::queue()
     * @param	int						$offset	Offset
     * @return	array( 'text' => 'Doing something...', 'complete' => 50 )	Text explaining task and percentage complete
     * @throws	\OutOfRangeException	Indicates offset doesn't exist and thus task is complete
     */
    public function getProgress($data, $offset) {
        return array('text' => '(NE) Hide content - not doing anything...', 'complete' => 50);
    }

    /**
     * Perform post-completion processing
     *
     * @param	array	$data		Data returned from preQueueData
     * @param	bool	$processed	Was anything processed or not? If preQueueData returns NULL, this will be FALSE.
     * @return	void
     */
    public function postComplete($data, $processed = TRUE) {
        
    }

}
