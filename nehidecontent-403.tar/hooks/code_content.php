//<?php
/* To prevent PHP errors (extending class does not exist) revealing path */
if (!\defined('\IPS\SUITE_UNIQUE_KEY')) {
    exit;
}

abstract class nehidecontent_hook_code_content extends _HOOK_CLASS_ {

    public function content() {
	try
	{
	        try {
	            if (\IPS\Request::i()->app == 'forums') {
	                if ($this->isFirst() AND!\IPS\Settings::i()->neapp_hidecontent_includefirstpost) {
	                    return parent::content();
	                }
	            }
	            if (\IPS\nehidecontent\CheckStuff::checkApp($this)) {
	                $content = parent::content();
	                $css = \IPS\Theme::i()->css('nehidecontent.css', 'nehidecontent', 'front');
	                if (!\in_array($css[0], \IPS\Output::i()->cssFiles)) {
	                    \IPS\Output::i()->cssFiles = array_merge(\IPS\Output::i()->cssFiles, $css);
	                }
	                if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent AND ( \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups)))) {
	                    return \IPS\nehidecontent\ProcessStuff::processContent($content, false);
	                } else {
	                    return \IPS\nehidecontent\ProcessStuff::processContent($content, true);
	                }
	            } else {
	                return parent::content();
	            }
	        } catch (Exception $ex) {
	            return parent::content();
	        }
	}
	catch ( \Error | \RuntimeException $e )
	{
		if ( method_exists( get_parent_class(), __FUNCTION__ ) )
		{
			return \call_user_func_array( 'parent::' . __FUNCTION__, \func_get_args() );
		}
		else
		{
			throw $e;
		}
	}
    }

}
