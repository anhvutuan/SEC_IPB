//<?php
/* To prevent PHP errors (extending class does not exist) revealing path */
if (!\defined('\IPS\SUITE_UNIQUE_KEY')) {
    exit;
}

abstract class nehidecontent_hook_code_content_item extends _HOOK_CLASS_ {

    protected function _comments($class, $limit, $offset = NULL, $order = 'date DESC', $member = NULL, $includeHidden = NULL, $cutoff = NULL, $canViewWarn = NULL, $extraWhereClause = NULL, $includeDeleted = false) {
	try
	{
	        $supportedApps = array(
	            'forums',
	            'cms',
	            'calendar'
	        );
	        if (!\in_array(\IPS\Request::i()->app, $supportedApps)) {
	            return parent::_comments($class, $limit, $offset, $order, $member, $includeHidden, $cutoff, $canViewWarn, $extraWhereClause, $includeDeleted);
	        } else {
	            $comments = parent::_comments($class, $limit, $offset, $order, $member, $includeHidden, $cutoff, $canViewWarn, $extraWhereClause, $includeDeleted);
            //First, restrict the number of comments returned
	            if (!\is_array($comments) OR empty($comments)) {
	                return $comments; //Do nothing - either a newly created topic or there are no comments
	            } else {
	                if (!\IPS\Settings::i()->neapp_hidecontent_hideallcontent) {
	                    return $comments;
	                }
                //Do the stuff
                //Get item ID
	                foreach ($comments as $k => $v) {
	                    switch (\IPS\Request::i()->app) {
	                        case 'forums':
	                            $item = $v;
	                            $itemId = $item->topic_id;
	                            $itemParent = \IPS\forums\Topic::load($itemId);
	                            if ($itemParent->isQuestion()) {
	                                return $comments;
	                            }
	                            break;
	                        case 'cms':
	                            $item = $v;
	                            $itemId = $v->record_id;
	                            break;
	                        case 'calendar':
	                            $item = $v;
	                            $itemId = $v->eid;
	                            break;
	                    }
	                    break;
	                }
	                if (\IPS\nehidecontent\CheckStuff::checkApp($item)) {
	                    if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent) {
	                        if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups))) {
	                            switch (\IPS\Request::i()->app) {
	                                case 'forums':
	                                    $counter = 0; //First post in a topic is included, innit??!!
	                                    $settingEnabled = \IPS\Settings::i()->neapp_hidecontent_limitcomments_forums;
	                                    $settingValue = \IPS\Settings::i()->neapp_hidecontent_limitcomments_forums_value;
	                                    $notificationAction = \IPS\Settings::i()->neapp_hidecontent_limitcomments_forums_notification;
	                                    break;
	                                case 'cms':
	                                    $counter = 1;
	                                    if (mb_strpos(\get_class($item), 'IPS\cms\Records\Comment', 0) !== FALSE) {
	                                        $settingEnabled = \IPS\Settings::i()->neapp_hidecontent_limitcomments_cms;
	                                        $settingValue = \IPS\Settings::i()->neapp_hidecontent_limitcomments_cms_value;
	                                    }
	                                    if (mb_strpos(\get_class($item), 'IPS\cms\Records\Review', 0) !== FALSE) {
	                                        $settingEnabled = \IPS\Settings::i()->neapp_hidecontent_limitreviews_cms;
	                                        $settingValue = \IPS\Settings::i()->neapp_hidecontent_limitreviews_cms_value;
	                                    }
	                                    break;
	                                case 'calendar':
	                                    $counter = 1;
	                                    if (mb_strpos(\get_class($item), 'IPS\calendar\Event\Comment', 0) !== FALSE) {
	                                        $settingEnabled = \IPS\Settings::i()->neapp_hidecontent_limitcomments_calendar;
	                                        $settingValue = \IPS\Settings::i()->neapp_hidecontent_limitcomments_calendar_value;
	                                    }
	                                    if (mb_strpos(\get_class($item), 'IPS\calendar\Event\Review', 0) !== FALSE) {
	                                        $settingEnabled = \IPS\Settings::i()->neapp_hidecontent_limitreviews_calendar;
	                                        $settingValue = \IPS\Settings::i()->neapp_hidecontent_limitreviews_calendar_value;
	                                    }
	                                    break;
	                            }
	                            if ($settingEnabled) {
	                                if (ISSET(\IPS\Request::i()->do) AND \IPS\Request::i()->do == 'checkForNewReplies') {
	                                    if (ISSET(\IPS\Request::i()->type) AND \IPS\Request::i()->type == 'count') {
	                                        if ($notificationAction) {
	                                            return array();
	                                        }
	                                    }
	                                }
	                               
	                                foreach ($comments as $k => $v) {
	                                    if ($counter >= $settingValue + 1) {
	                                        unset($comments[$k]);
	                                    }
	                                    $counter++;
	                                }
	                            }
	                        }
	                    }
	                }
	            }
            //A little check to see if this is being loaded by the 'checkForNewReplies' from the front-end
	            if (ISSET(\IPS\Request::i()->do) AND \IPS\Request::i()->do == 'checkForNewReplies') {
	                if (ISSET(\IPS\Request::i()->type) AND \IPS\Request::i()->type == 'fetch') {
	                    foreach ($comments as $k => $v) {
	                        if (\IPS\nehidecontent\CheckStuff::checkApp($v)) {
	                            if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent AND ( \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups)))) {
	                                $v->post = \IPS\nehidecontent\ProcessStuff::processContent($v->post, false);
	                            } else {
	                                $v->post = \IPS\nehidecontent\ProcessStuff::processContent($v->post, true);
	                            }
	                        }
	                    }
	                }
	            }
	            return $comments;
	        }
	}
	catch ( \Error | \RuntimeException $e )
	{
		if ( method_exists( get_parent_class(), __FUNCTION__ ) )
		{
			return \call_user_func_array( 'parent::' . __FUNCTION__, \func_get_args() );
		}
		else
		{
			throw $e;
		}
	}
    }

    public function commentPageCount($recache = false) {
	try
	{
	        $app = \IPS\Request::i()->app;
	        $module = \IPS\Request::i()->module;
	        $controller = \IPS\Request::i()->controller;
	        $test = parent::commentPageCount($recache);
	        if ($app === 'forums' AND $module === 'forums' AND $controller === 'topic') {
	            if (\IPS\Request::i()->isAjax() OR \IPS\nehidecontent\CheckStuff::oldPluginEnabled() OR \IPS\Request::i()->do != '') {
	                return $test;
	            }
	            if (\IPS\Settings::i()->neapp_hidecontent_hide_where_forums) {
	                if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent) {
	                    if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups))) {
	                        if (\IPS\Settings::i()->neapp_hidecontent_limitcomments_forums) {
	                            $commentCount = \IPS\Settings::i()->neapp_hidecontent_limitcomments_forums_value + 1;
	                            $tempPageCount = ceil($commentCount / $this->getCommentsPerPage());
	                            if ($tempPageCount < 1) {
	                                $tempPageCount = 1;
	                            }
	                            return $tempPageCount;
	                        } else {
	                            return $test;
	                        }
	                    }
	                }
	            }
	            return $test;
	        } elseif ($app === 'cms' AND $module === 'pages' AND $controller === 'page') {
	            if ((\IPS\Request::i()->isAjax() AND!isset(\IPS\Request::i()->tab)) OR \IPS\nehidecontent\CheckStuff::oldPluginEnabled() OR \IPS\Request::i()->do != '') {
	                return $test;
	            }
	            if (\IPS\Settings::i()->neapp_hidecontent_hide_where_cms) {
	                if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent) {
	                    if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups))) {
	                        if (!isset(\IPS\Request::i()->tab) OR (isset(\IPS\Request::i()->tab) AND \IPS\Request::i()->tab == 'comments')) {
	                            if (\IPS\Settings::i()->neapp_hidecontent_limitcomments_cms) {
	                                $commentCount = \IPS\Settings::i()->neapp_hidecontent_limitcomments_cms_value + 1;
	                                $tempPageCount = ceil($commentCount / $this->getCommentsPerPage());
	                                if ($tempPageCount < 1) {
	                                    $tempPageCount = 1;
	                                }
	                                return $tempPageCount;
	                            }
	                        }
	                        if (!isset(\IPS\Request::i()->tab) OR (isset(\IPS\Request::i()->tab) AND \IPS\Request::i()->tab == 'reviews')) {
	                            if (\IPS\Settings::i()->neapp_hidecontent_limitreviews_cms) {
	                                $commentCount = \IPS\Settings::i()->neapp_hidecontent_limitreviews_cms_value + 1;
	                                $tempPageCount = ceil($commentCount / $this->getCommentsPerPage());
	                                if ($tempPageCount < 1) {
	                                    $tempPageCount = 1;
	                                }
	                                return $tempPageCount;
	                            }
	                        }
	                    }
	                }
	            }
	            return $test;
	        } else {
	            return parent::commentPageCount($recache);
	        }
	}
	catch ( \Error | \RuntimeException $e )
	{
		if ( method_exists( get_parent_class(), __FUNCTION__ ) )
		{
			return \call_user_func_array( 'parent::' . __FUNCTION__, \func_get_args() );
		}
		else
		{
			throw $e;
		}
	}
    }

}
