//<?php
/* To prevent PHP errors (extending class does not exist) revealing path */
if (!\defined('\IPS\SUITE_UNIQUE_KEY')) {
    exit;
}

class nehidecontent_hook_code_content_search_result_conte extends _HOOK_CLASS_ {

    /**
     * HTML
     *
     * @param	string	$view	'expanded' or 'condensed'
     * @param	bool	$asItem	Displaying results as items?
     * @param	bool	$canIgnoreComments	Can ignore comments in the result stream? Activity stream can, but search results cannot.
     * @param	array|NULL	$template	Optional custom template
     * @return	string
     */
    public function html($view = 'expanded', $asItem = false, $canIgnoreComments = false, $template = NULL) {
	try
	{
	        try {
	            $data['index_class'] = $this->indexData['index_class'];
	            $data['index_container_id'] = $this->indexData['index_container_id'];
	            $data['index_item_id'] = $this->indexData['index_item_id'];
	
	            if (\IPS\nehidecontent\CheckStuff::checkSearch($data)) {
	                $this->indexData['index_content'] = \IPS\Settings::i()->neapp_hidecontent_hidesearch_text;
	            }
	            return parent::html($view, $asItem, $canIgnoreComments, $template);
	        } catch (Exception $ex) {
	            return parent::html($view, $asItem, $canIgnoreComments, $template);
	        }
	}
	catch ( \Error | \RuntimeException $e )
	{
		if ( method_exists( get_parent_class(), __FUNCTION__ ) )
		{
			return \call_user_func_array( 'parent::' . __FUNCTION__, \func_get_args() );
		}
		else
		{
			throw $e;
		}
	}
    }

}
