//<?php
/* To prevent PHP errors (extending class does not exist) revealing path */
if (!\defined('\IPS\SUITE_UNIQUE_KEY')) {
    exit;
}

class nehidecontent_hook_code_dispatcher_front extends _HOOK_CLASS_ {

    

}
