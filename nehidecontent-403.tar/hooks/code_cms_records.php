//<?php
/* To prevent PHP errors (extending class does not exist) revealing path */
if (!\defined('\IPS\SUITE_UNIQUE_KEY')) {
    exit;
}

class nehidecontent_hook_code_cms_records extends _HOOK_CLASS_ {

    /**
     * Get the record content for display
     *
     * @return	string
     */
    public function get__content() {
	try
	{
	        try {
	            if (\IPS\nehidecontent\CheckStuff::checkApp($this)) {
	                $content = parent::get__content();
	                if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent AND ( \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups)))) {
	                    return \IPS\nehidecontent\ProcessStuff::processContent($content, false);
	                } else {
	                    return \IPS\nehidecontent\ProcessStuff::processContent($content, true);
	                }
	            } else {
	                return parent::get__content();
	            }
	        } catch (Exception $ex) {
	            return parent::get__content();
	        }
	}
	catch ( \Error | \RuntimeException $e )
	{
		if ( method_exists( get_parent_class(), __FUNCTION__ ) )
		{
			return \call_user_func_array( 'parent::' . __FUNCTION__, \func_get_args() );
		}
		else
		{
			throw $e;
		}
	}
    }

    public function mapped($key) {
	try
	{
	        if ($key !== 'num_comments' AND $key !== 'num_reviews') {
	            return parent::mapped($key);
	        } else {
	            if (\IPS\Settings::i()->neapp_hidecontent_hide_where_cms AND \IPS\Settings::i()->neapp_hidecontent_hideallcontent) {
	                if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups))) {
	                    if (\IPS\cms\Databases\Dispatcher::i()->module=='record') {
	                        if ($key == 'num_comments' AND \IPS\Settings::i()->neapp_hidecontent_limitcomments_cms) {
	                            $current = parent::mapped($key);
	                            if ($current > \IPS\Settings::i()->neapp_hidecontent_limitcomments_cms_value) {
	                                return \IPS\Settings::i()->neapp_hidecontent_limitcomments_cms_value;
	                            }
	                        }
	                        if ($key == 'num_reviews' AND \IPS\Settings::i()->neapp_hidecontent_limitreviews_cms) {
	                            $current = parent::mapped($key);
	                            if ($current > \IPS\Settings::i()->neapp_hidecontent_limitreviews_cms_value) {
	                                return \IPS\Settings::i()->neapp_hidecontent_limitreviews_cms_value;
	                            }
	                        }
	                    }
	                }
	            }
	        }
	        return parent::mapped($key);
	}
	catch ( \Error | \RuntimeException $e )
	{
		if ( method_exists( get_parent_class(), __FUNCTION__ ) )
		{
			return \call_user_func_array( 'parent::' . __FUNCTION__, \func_get_args() );
		}
		else
		{
			throw $e;
		}
	}
    }

    public function originalMapped($key) {
	try
	{
	
	        if ($key !== 'num_comments') {
	            return parent::mapped($key);
	        } else {
	            $current = parent::mapped($key);
	            $neDoIt = true;
	            if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent) {
	                if (\IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups === '*' OR \IPS\Member::loggedIn()->inGroup(explode(',', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups))) {
	                    if (\IPS\Settings::i()->neapp_hidecontent_limitcomments_cms) {
	                        $fid = \IPS\cms\Databases\Dispatcher::i()->databaseId;
	                        $tid = \IPS\cms\Databases\Dispatcher::i()->recordId;
	                        if (
	                                \IPS\nehidecontent\NeContent::neAppHideContentCheckWhetherToApply($fid, true, $tid, 'cms')
	                                OR
	                                \IPS\nehidecontent\NeContent::neAppHideContentCheckWhetherToApply($fid, true, NULL, 'cms')
	                        ) {
                            //Needed to figure out a way to have this only be done for viewing a record
                            //as the value is used in 2 places - record listing and record viewing
                            //It's not pretty, involves checking through the backtrace for a function that only
                            //runs on the record listing side of things.
	                            $neBackTrace = debug_backtrace(0);
	                            foreach ($neBackTrace as $k => $v) {
	                                if ($v['function'] == '__toString') {
	                                    $neDoIt = false;
	                                    break;
	                                }
	                            }
	                            if ($neDoIt) {
	                                $new = \IPS\Settings::i()->neapp_hidecontent_limitcomments_cms_value;
	                                return $new;
	                            } else {
	                                return $current;
	                            }
	                        } else {
	                            return $current;
	                        }
	                    } else {
	                        return $current;
	                    }
	                } else {
	                    return $current;
	                }
	            } else {
	                return $current;
	            }
	        }
	}
	catch ( \Error | \RuntimeException $e )
	{
		if ( method_exists( get_parent_class(), __FUNCTION__ ) )
		{
			return \call_user_func_array( 'parent::' . __FUNCTION__, \func_get_args() );
		}
		else
		{
			throw $e;
		}
	}
    }

}
