<?php

namespace IPS\nehidecontent\modules\admin\nehidecontent;

/* To prevent PHP errors (extending class does not exist) revealing path */
if (!\defined('\IPS\SUITE_UNIQUE_KEY')) {
    header(( isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden');
    exit;
}

/**
 * nehcsettings
 */
class _nehcsettings extends \IPS\Dispatcher\Controller {

    /**
     * Execute
     *
     * @return	void
     */
    public function execute() {
        \IPS\Dispatcher::i()->checkAcpPermission('nehcsettings_manage');
        parent::execute();
    }

    /**
     * ...
     *
     * @return	void
     */
    protected function manage() {
        $messageTypes = array('code' => 'Code', 'general' => 'General', 'information' => 'Information', 'error' => 'Error', 'success' => 'Success');
        //Set up some additional language strings - one size fitz hall approach, saves duplication in the lang.php
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidesearch_text'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_replacement_text');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideallcontent_text'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_replacement_text');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideallcontent_messagetype'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideallcontent_messagetype_desc'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type_desc');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideattachments_text'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_replacement_text');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideattachments_messagetype'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideattachments_messagetype_desc'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type_desc');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidecode_text'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_replacement_text');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidecode_messagetype'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidecode_messagetype_desc'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type_desc');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideimages_text'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_replacement_text');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideimages_messagetype'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideimages_messagetype_desc'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type_desc');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidelinks_text'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_replacement_text');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidelinks_messagetype'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidelinks_messagetype_desc'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type_desc');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidequotes_text'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_replacement_text');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidequotes_messagetype'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidequotes_messagetype_desc'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type_desc');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidespoilers_text'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_replacement_text');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidespoilers_messagetype'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidespoilers_messagetype_desc'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type_desc');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidevideos_text'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_replacement_text');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidevideos_messagetype'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidevideos_messagetype_desc'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type_desc');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideaudio_text'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_replacement_text');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideaudio_messagetype'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideaudio_messagetype_desc'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_ipsmessage_type_desc');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideallcontent'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hideallcontent_tab');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideattachments'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hideattachments_tab');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidecode'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hidecode_tab');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideimages'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hideimages_tab');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidelinks'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hidelinks_tab');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidequotes'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hidequotes_tab');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidespoilers'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hidespoilers_tab');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidevideos'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hidevideos_tab');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideaudio'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hideaudio_tab');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidesearch_groups'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hide_groups');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideallcontent_groups'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hide_groups');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideattachments_groups'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hide_groups');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidecode_groups'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hide_groups');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideimages_groups'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hide_groups');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidelinks_groups'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hide_groups');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidequotes_groups'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hide_groups');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidespoilers_groups'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hide_groups');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidevideos_groups'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hide_groups');
        \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hideaudio_groups'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hide_groups');

        //Display warning if plugin version hasn't yet been deleted via the task queue
        if (\IPS\nehidecontent\CheckStuff::oldPluginEnabled()) {
            \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hide_where_forums_warning'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_plugin_enabled');
            \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hide_where_cms_warning'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_plugin_enabled');
            \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hide_where_calendar_warning'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_plugin_enabled');
        }
        //Display information regarding what happens with videos in the event
        //that my HTML Player application (not plugin) is installed
        if (\IPS\nehidecontent\CheckStuff::htmlPlayerAppEnabled()['enabled']) {
            if (\IPS\nehidecontent\CheckStuff::htmlPlayerAppEnabled()['position']) {
                \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidevideos_external_warning'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hidevideos_neapphtmlplayer_enabledbefore');
            } else {
                \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_hidevideos_external_warning'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_hidevideos_neapphtmlplayer_enabledafter');
            }
        }
        //Set up the form
        $form = new \IPS\Helpers\Form;
        $form->addTab('neapp_hidecontent_hide_tab');
        $form->addHeader('neapp_hidecontent_hide_where');
        if (\in_array('forums', array_keys(\IPS\Application::applications())) AND \IPS\Application::appIsEnabled('forums')) {
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hide_where_forums', \IPS\Settings::i()->neapp_hidecontent_hide_where_forums, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hide_where_forums_tab"), 'togglesOff' => array()), NULL, NULL, NULL, 'neapp_hidecontent_hide_where_forums'));
        }
        if (\in_array('cms', array_keys(\IPS\Application::applications())) AND \IPS\Application::appIsEnabled('cms')) {
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hide_where_cms', \IPS\Settings::i()->neapp_hidecontent_hide_where_cms, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hide_where_cms_tab"), 'togglesOff' => array()), NULL, NULL, NULL, 'neapp_hidecontent_hide_where_cms'));
        }
        if (\in_array('calendar', array_keys(\IPS\Application::applications())) AND \IPS\Application::appIsEnabled('calendar')) {
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hide_where_calendar', \IPS\Settings::i()->neapp_hidecontent_hide_where_calendar, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hide_where_calendar_tab"), 'togglesOff' => array()), NULL, NULL, NULL, 'neapp_hidecontent_hide_where_calendar'));
        }
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hide_where_search', \IPS\Settings::i()->neapp_hidecontent_hide_where_search, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hide_where_search_tab"), 'togglesOff' => array()), NULL, NULL, NULL, 'neapp_hidecontent_hide_where_search'));
        $form->addHeader('neapp_hidecontent_hide_what');
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hideallcontent', \IPS\Settings::i()->neapp_hidecontent_hideallcontent, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hideallcontent_tab", 'neapp_hidecontent_limitcomments_forums', 'neapp_hidecontent_limitcomments_cms', 'neapp_hidecontent_limitreviews_cms', 'neapp_hidecontent_limitcomments_calendar', 'neapp_hidecontent_limitreviews_calendar'), 'togglesOff' => array('neapp_hidecontent_hideattachments', 'neapp_hidecontent_hidecode', 'neapp_hidecontent_hideimages', 'neapp_hidecontent_hidelinks', 'neapp_hidecontent_hidequotes', 'neapp_hidecontent_hidespoilers', 'neapp_hidecontent_hidevideos', 'neapp_hidecontent_hideaudio', 'neapp_hidecontent_mergehidemessages')), NULL, NULL, NULL, 'neapp_hidecontent_hideallcontent'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hideattachments', \IPS\Settings::i()->neapp_hidecontent_hideallcontent === 1 ? 0 : \IPS\Settings::i()->neapp_hidecontent_hideattachments, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hideattachments_tab"), 'togglesOff' => array()), NULL, NULL, NULL, 'neapp_hidecontent_hideattachments'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hidecode', \IPS\Settings::i()->neapp_hidecontent_hideallcontent === 1 ? 0 : \IPS\Settings::i()->neapp_hidecontent_hidecode, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hidecode_tab"), 'togglesOff' => array()), NULL, NULL, NULL, 'neapp_hidecontent_hidecode'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hideimages', \IPS\Settings::i()->neapp_hidecontent_hideallcontent === 1 ? 0 : \IPS\Settings::i()->neapp_hidecontent_hideimages, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hideimages_tab"), 'togglesOff' => array()), NULL, NULL, NULL, 'neapp_hidecontent_hideimages'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hidelinks', \IPS\Settings::i()->neapp_hidecontent_hideallcontent === 1 ? 0 : \IPS\Settings::i()->neapp_hidecontent_hidelinks, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hidelinks_tab"), 'togglesOff' => array()), NULL, NULL, NULL, 'neapp_hidecontent_hidelinks'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hidequotes', \IPS\Settings::i()->neapp_hidecontent_hideallcontent === 1 ? 0 : \IPS\Settings::i()->neapp_hidecontent_hidequotes, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hidequotes_tab"), 'togglesOff' => array()), NULL, NULL, NULL, 'neapp_hidecontent_hidequotes'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hidespoilers', \IPS\Settings::i()->neapp_hidecontent_hideallcontent === 1 ? 0 : \IPS\Settings::i()->neapp_hidecontent_hidespoilers, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hidespoilers_tab"), 'togglesOff' => array()), NULL, NULL, NULL, 'neapp_hidecontent_hidespoilers'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hidevideos', \IPS\Settings::i()->neapp_hidecontent_hideallcontent === 1 ? 0 : \IPS\Settings::i()->neapp_hidecontent_hidevideos, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hidevideos_tab"), 'togglesOff' => array()), NULL, NULL, NULL, 'neapp_hidecontent_hidevideos'));
        if (\IPS\Application::load('core')->long_version >= 106138) {
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hideaudio', \IPS\Settings::i()->neapp_hidecontent_hideallcontent === 1 ? 0 : \IPS\Settings::i()->neapp_hidecontent_hideaudio, FALSE, array('togglesOn' => array("{$form->id}_tab_neapp_hidecontent_hideaudio_tab"), 'togglesOff' => array()), NULL, NULL, NULL, 'neapp_hidecontent_hideaudio'));
        }
        if (\in_array('forums', array_keys(\IPS\Application::applications())) AND \IPS\Application::appIsEnabled('forums')) {
            $form->addTab('neapp_hidecontent_hide_where_forums_tab');
            $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_forum_type', \IPS\Settings::i()->neapp_hidecontent_forum_type, FALSE, array('options' => array(0 => 'Include', 1 => 'Exclude'), 'toggles' => array(0 => array('neapp_hidecontent_include_forums'), 1 => array('neapp_hidecontent_exclude_forums'))), NULL, NULL, NULL, 'neapp_hidecontent_forum_type'));
            $form->add(new \IPS\Helpers\Form\Node('neapp_hidecontent_include_forums', \IPS\Settings::i()->neapp_hidecontent_include_forums ? \IPS\Settings::i()->neapp_hidecontent_include_forums : 0, FALSE, array('class' => 'IPS\forums\Forum', 'zeroVal' => 'All forums', 'multiple' => TRUE), NULL, NULL, NULL, 'neapp_hidecontent_include_forums'));
            $form->add(new \IPS\Helpers\Form\Node('neapp_hidecontent_exclude_forums', \IPS\Settings::i()->neapp_hidecontent_exclude_forums ? \IPS\Settings::i()->neapp_hidecontent_exclude_forums : 0, FALSE, array('class' => 'IPS\forums\Forum', 'zeroVal' => 'All forums', 'multiple' => TRUE), NULL, NULL, NULL, 'neapp_hidecontent_exclude_forums'));
            $form->add(new \IPS\Helpers\Form\Item('neapp_hidecontent_exclude_topics', \IPS\Settings::i()->neapp_hidecontent_exclude_topics, FALSE, array('class' => '\IPS\forums\Topic', 'maxItems' => NULL, 'minAjaxLength' => 3), NULL, NULL, NULL, 'neapp_hidecontent_exclude_topics'));
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_includefirstpost', \IPS\Settings::i()->neapp_hidecontent_includefirstpost, FALSE, array()));
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_limitcomments_forums', \IPS\Settings::i()->neapp_hidecontent_limitcomments_forums, FALSE, array('togglesOn' => array('neapp_hidecontent_limitcomments_forums_value', 'neapp_hidecontent_limitcomments_forums_notification')), NULL, NULL, NULL, 'neapp_hidecontent_limitcomments_forums'));
            $form->add(new \IPS\Helpers\Form\Number('neapp_hidecontent_limitcomments_forums_value', \IPS\Settings::i()->neapp_hidecontent_limitcomments_forums_value, FALSE, array('min' => 0), NULL, NULL, NULL, 'neapp_hidecontent_limitcomments_forums_value'));
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_limitcomments_forums_notification', \IPS\Settings::i()->neapp_hidecontent_limitcomments_forums_notification, FALSE, array(), NULL, NULL, NULL, 'neapp_hidecontent_limitcomments_forums_notification'));
        }
        if (\in_array('cms', array_keys(\IPS\Application::applications())) AND \IPS\Application::appIsEnabled('cms')) {
            \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_cms_comments_databases'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_cms_databases');
            \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_cms_reviews_databases'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_cms_databases');
            $form->addTab('neapp_hidecontent_hide_where_cms_tab');
            $form->addHeader("Records");
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_cms_databases_enabled', \IPS\Settings::i()->neapp_hidecontent_cms_databases_enabled, FALSE, array('togglesOn' => array('neapp_hidecontent_cms_databases')), NULL, NULL, NULL, 'neapp_hidecontent_cms_databases_enabled'));
            $form->add(new \IPS\Helpers\Form\Node('neapp_hidecontent_cms_databases', \IPS\Settings::i()->neapp_hidecontent_cms_databases ? \IPS\Settings::i()->neapp_hidecontent_cms_databases : 0, FALSE, array('class' => '\IPS\cms\Databases', 'zeroVal' => 'All databases', 'multiple' => TRUE), function ($val) {
                                if ($val === '') {
                                    throw new \DomainException('neapp_hidecontent_cms_database_valid');
                                }
                            }, NULL, NULL, 'neapp_hidecontent_cms_databases'));
            $form->addHeader("Comments");
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_cms_comments_enabled', \IPS\Settings::i()->neapp_hidecontent_cms_comments_enabled, FALSE, array('togglesOn' => array('neapp_hidecontent_cms_comments_databases')), NULL, NULL, NULL, 'neapp_hidecontent_cms_comments_enabled'));
            $form->add(new \IPS\Helpers\Form\Node('neapp_hidecontent_cms_comments_databases', \IPS\Settings::i()->neapp_hidecontent_cms_comments_databases ? \IPS\Settings::i()->neapp_hidecontent_cms_comments_databases : 0, FALSE, array('class' => '\IPS\cms\Databases', 'zeroVal' => 'All databases', 'multiple' => TRUE), function ($val) {
                                if ($val === '') {
                                    throw new \DomainException('neapp_hidecontent_cms_database_valid');
                                }
                            }, NULL, NULL, 'neapp_hidecontent_cms_comments_databases'));
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_limitcomments_cms', \IPS\Settings::i()->neapp_hidecontent_limitcomments_cms, FALSE, array('togglesOn' => array('neapp_hidecontent_limitcomments_cms_value')), NULL, NULL, NULL, 'neapp_hidecontent_limitcomments_cms'));
            $form->add(new \IPS\Helpers\Form\Number('neapp_hidecontent_limitcomments_cms_value', \IPS\Settings::i()->neapp_hidecontent_limitcomments_cms_value, FALSE, array('min' => 0), NULL, NULL, NULL, 'neapp_hidecontent_limitcomments_cms_value'));
            $form->addHeader("Reviews");
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_cms_reviews_enabled', \IPS\Settings::i()->neapp_hidecontent_cms_reviews_enabled, FALSE, array('togglesOn' => array('neapp_hidecontent_cms_reviews_databases')), NULL, NULL, NULL, 'neapp_hidecontent_cms_reviews_enabled'));
            $form->add(new \IPS\Helpers\Form\Node('neapp_hidecontent_cms_reviews_databases', \IPS\Settings::i()->neapp_hidecontent_cms_reviews_databases ? \IPS\Settings::i()->neapp_hidecontent_cms_reviews_databases : 0, FALSE, array('class' => '\IPS\cms\Databases', 'zeroVal' => 'All databases', 'multiple' => TRUE), function ($val) {
                                if ($val === '') {
                                    throw new \DomainException('neapp_hidecontent_cms_database_valid');
                                }
                            }, NULL, NULL, 'neapp_hidecontent_cms_reviews_databases'));
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_limitreviews_cms', \IPS\Settings::i()->neapp_hidecontent_limitreviews_cms, FALSE, array('togglesOn' => array('neapp_hidecontent_limitreviews_cms_value')), NULL, NULL, NULL, 'neapp_hidecontent_limitreviews_cms'));
            $form->add(new \IPS\Helpers\Form\Number('neapp_hidecontent_limitreviews_cms_value', \IPS\Settings::i()->neapp_hidecontent_limitreviews_cms_value, FALSE, array('min' => 0), NULL, NULL, NULL, 'neapp_hidecontent_limitreviews_cms_value'));
        }

        if (\in_array('calendar', array_keys(\IPS\Application::applications())) AND \IPS\Application::appIsEnabled('calendar')) {
            \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_calendar_calendars_events'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_calendar_calendars');
            \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_calendar_calendars_comments'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_calendar_calendars');
            \IPS\Member::loggedIn()->language()->words['neapp_hidecontent_calendar_calendars_reviews'] = \IPS\Member::loggedIn()->language()->addToStack('neapp_hidecontent_calendar_calendars');

            $form->addTab('neapp_hidecontent_hide_where_calendar_tab');
            $form->addHeader("Events");

            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_calendar_event', \IPS\Settings::i()->neapp_hidecontent_calendar_event, FALSE, array('togglesOn' => array('neapp_hidecontent_calendar_calendars_events'))));
            $form->add(new \IPS\Helpers\Form\Node('neapp_hidecontent_calendar_calendars_events', \IPS\Settings::i()->neapp_hidecontent_calendar_calendars_events ? \IPS\Settings::i()->neapp_hidecontent_calendar_calendars_events : 0, FALSE, array('class' => '\IPS\calendar\Calendar', 'zeroVal' => 'All calendars', 'multiple' => TRUE), function ($val) {
                                if ($val === '') {
                                    throw new \DomainException('neapp_hidecontent_calendar_calendars_valid');
                                }
                            }, NULL, NULL, 'neapp_hidecontent_calendar_calendars_events'));
            $form->addHeader("Comments");
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_calendar_comments', \IPS\Settings::i()->neapp_hidecontent_calendar_comments, FALSE, array('togglesOn' => array('neapp_hidecontent_calendar_calendars_comments'))));
            $form->add(new \IPS\Helpers\Form\Node('neapp_hidecontent_calendar_calendars_comments', \IPS\Settings::i()->neapp_hidecontent_calendar_calendars_comments ? \IPS\Settings::i()->neapp_hidecontent_calendar_calendars_comments : 0, FALSE, array('class' => '\IPS\calendar\Calendar', 'zeroVal' => 'All calendars', 'multiple' => TRUE), function ($val) {
                                if ($val === '') {
                                    throw new \DomainException('neapp_hidecontent_calendar_calendars_valid');
                                }
                            }, NULL, NULL, 'neapp_hidecontent_calendar_calendars_comments'));
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_limitcomments_calendar', \IPS\Settings::i()->neapp_hidecontent_limitcomments_calendar, FALSE, array('togglesOn' => array('neapp_hidecontent_limitcomments_calendar_value')), NULL, NULL, NULL, 'neapp_hidecontent_limitcomments_calendar'));
            $form->add(new \IPS\Helpers\Form\Number('neapp_hidecontent_limitcomments_calendar_value', \IPS\Settings::i()->neapp_hidecontent_limitcomments_calendar_value, FALSE, array('min' => 0), NULL, NULL, NULL, 'neapp_hidecontent_limitcomments_calendar_value'));
            $form->addHeader("Reviews");
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_calendar_reviews', \IPS\Settings::i()->neapp_hidecontent_calendar_reviews, FALSE, array('togglesOn' => array('neapp_hidecontent_calendar_calendars_reviews'))));
            $form->add(new \IPS\Helpers\Form\Node('neapp_hidecontent_calendar_calendars_reviews', \IPS\Settings::i()->neapp_hidecontent_calendar_calendars_reviews ? \IPS\Settings::i()->neapp_hidecontent_calendar_calendars_reviews : 0, FALSE, array('class' => '\IPS\calendar\Calendar', 'zeroVal' => 'All calendars', 'multiple' => TRUE), function ($val) {
                                if ($val === '') {
                                    throw new \DomainException('neapp_hidecontent_calendar_calendars_valid');
                                }
                            }, NULL, NULL, 'neapp_hidecontent_calendar_calendars_reviews'));
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_limitreviews_calendar', \IPS\Settings::i()->neapp_hidecontent_limitreviews_calendar, FALSE, array('togglesOn' => array('neapp_hidecontent_limitreviews_calendar_value')), NULL, NULL, NULL, 'neapp_hidecontent_limitreviews_calendar'));
            $form->add(new \IPS\Helpers\Form\Number('neapp_hidecontent_limitreviews_calendar_value', \IPS\Settings::i()->neapp_hidecontent_limitreviews_calendar_value, FALSE, array('min' => 0), NULL, NULL, NULL, 'neapp_hidecontent_limitreviews_calendar_value'));
        }
        $form->addTab('neapp_hidecontent_hide_where_search_tab');
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hidesearch_groups', \IPS\Settings::i()->neapp_hidecontent_hidesearch_groups == '*' ? '*' : explode(',', \IPS\Settings::i()->neapp_hidecontent_hidesearch_groups), FALSE, array('options' => \IPS\Member\Group::groups(), 'parse' => 'normal', 'multiple' => TRUE, 'unlimited' => '*', 'unlimitedLang' => 'All Groups'), NULL, NULL, NULL, 'neapp_hidecontent_hidesearch_groups'));
        $form->add(new \IPS\Helpers\Form\Translatable('neapp_hidecontent_hidesearch_text', NULL, FALSE, array('app' => 'nehidecontent', 'key' => 'neapp_hidecontent_hidesearch_text_value'), NULL, NULL, NULL, 'neapp_hidecontent_hidesearch_text'));
        $form->addTab('neapp_hidecontent_hideallcontent_tab');
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hideallcontent_groups', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups == '*' ? '*' : explode(',', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_groups), FALSE, array('options' => \IPS\Member\Group::groups(), 'parse' => 'normal', 'multiple' => TRUE, 'unlimited' => '*', 'unlimitedLang' => 'All Groups'), NULL, NULL, NULL, 'neapp_hidecontent_hideallcontent_groups'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hideallcontent_skeleton_enabled', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_skeleton_enabled, FALSE, array('togglesOn' => array('neapp_hidecontent_hideallcontent_skeleton_include'),'togglesOff' => array('neapp_hidecontent_hideallcontent_messagetype_enabled')), NULL, NULL, NULL, 'neapp_hidecontent_hideallcontent_skeleton_enabled'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hideallcontent_skeleton_include', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_skeleton_include, FALSE, array(), NULL, NULL, NULL, 'neapp_hidecontent_hideallcontent_skeleton_include'));
        
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hideallcontent_messagetype_enabled', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_messagetype_enabled, FALSE, array('togglesOn' => array('neapp_hidecontent_hideallcontent_messagetype')), NULL, NULL, NULL, 'neapp_hidecontent_hideallcontent_messagetype_enabled'));
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hideallcontent_messagetype', \IPS\Settings::i()->neapp_hidecontent_hideallcontent_messagetype, FALSE, array('options' => $messageTypes), NULL, NULL, NULL, 'neapp_hidecontent_hideallcontent_messagetype'));
        $form->add(new \IPS\Helpers\Form\Translatable('neapp_hidecontent_hideallcontent_text', NULL, FALSE, array('app' => 'nehidecontent', 'key' => 'neapp_hidecontent_hideallcontent_text_value', 'editor' => array('app' => 'nehidecontent', 'key' => 'Settings', 'autoSaveKey' => 'neapp_hidecontent_hideallcontent_text_value')), NULL, NULL, NULL, 'neapp_hidecontent_hideallcontent_text'));
        $form->addTab('neapp_hidecontent_hideattachments_tab');
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hideattachments_groups', \IPS\Settings::i()->neapp_hidecontent_hideattachments_groups == '*' ? '*' : explode(',', \IPS\Settings::i()->neapp_hidecontent_hideattachments_groups), FALSE, array('options' => \IPS\Member\Group::groups(), 'parse' => 'normal', 'multiple' => TRUE, 'unlimited' => '*', 'unlimitedLang' => 'All Groups'), NULL, NULL, NULL, 'neapp_hidecontent_hideattachments_groups'));
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hideattachments_messagetype', \IPS\Settings::i()->neapp_hidecontent_hideattachments_messagetype, FALSE, array('options' => $messageTypes), NULL, NULL, NULL, 'neapp_hidecontent_hideattachments_messagetype'));
        $form->add(new \IPS\Helpers\Form\Translatable('neapp_hidecontent_hideattachments_text', NULL, FALSE, array('app' => 'nehidecontent', 'key' => 'neapp_hidecontent_hideattachments_text_value', 'editor' => array('app' => 'nehidecontent', 'key' => 'Settings', 'autoSaveKey' => 'neapp_hidecontent_hideattachments_text_value')), NULL, NULL, NULL, 'neapp_hidecontent_hideattachments_text'));
        $form->addTab('neapp_hidecontent_hidecode_tab');
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hidecode_groups', \IPS\Settings::i()->neapp_hidecontent_hidecode_groups == '*' ? '*' : explode(',', \IPS\Settings::i()->neapp_hidecontent_hidecode_groups), FALSE, array('options' => \IPS\Member\Group::groups(), 'parse' => 'normal', 'multiple' => TRUE, 'unlimited' => '*', 'unlimitedLang' => 'All Groups'), NULL, NULL, NULL, 'neapp_hidecontent_hidecode_groups'));
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hidecode_messagetype', \IPS\Settings::i()->neapp_hidecontent_hidecode_messagetype, FALSE, array('options' => $messageTypes), NULL, NULL, NULL, 'neapp_hidecontent_hidecode_messagetype'));
        $form->add(new \IPS\Helpers\Form\Translatable('neapp_hidecontent_hidecode_text', NULL, FALSE, array('app' => 'nehidecontent', 'key' => 'neapp_hidecontent_hidecode_text_value', 'editor' => array('app' => 'nehidecontent', 'key' => 'Settings', 'autoSaveKey' => 'neapp_hidecontent_hidecode_text_value')), NULL, NULL, NULL, 'neapp_hidecontent_hidecode_text'));
        $form->addTab('neapp_hidecontent_hideimages_tab');
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hideemoticons', \IPS\Settings::i()->neapp_hidecontent_hideemoticons, FALSE, array(), NULL, NULL, NULL, 'neapp_hidecontent_hideemoticons'));
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hideimages_groups', \IPS\Settings::i()->neapp_hidecontent_hideimages_groups == '*' ? '*' : explode(',', \IPS\Settings::i()->neapp_hidecontent_hideimages_groups), FALSE, array('options' => \IPS\Member\Group::groups(), 'parse' => 'normal', 'multiple' => TRUE, 'unlimited' => '*', 'unlimitedLang' => 'All Groups'), NULL, NULL, NULL, 'neapp_hidecontent_hideimages_groups'));
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hideimages_messagetype', \IPS\Settings::i()->neapp_hidecontent_hideimages_messagetype, FALSE, array('options' => $messageTypes), NULL, NULL, NULL, 'neapp_hidecontent_hideimages_messagetype'));
        $form->add(new \IPS\Helpers\Form\Translatable('neapp_hidecontent_hideimages_text', NULL, FALSE, array('app' => 'nehidecontent', 'key' => 'neapp_hidecontent_hideimages_text_value', 'editor' => array('app' => 'nehidecontent', 'key' => 'Settings', 'autoSaveKey' => 'neapp_hidecontent_hideimages_text_value')), NULL, NULL, NULL, 'neapp_hidecontent_hideimages_text'));
        $form->addTab('neapp_hidecontent_hidelinks_tab');
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hidelinks_internal', \IPS\Settings::i()->neapp_hidecontent_hidelinks_internal, FALSE, array('togglesOn' => array('neapp_hidecontent_hidelinks_internal_embeds')), NULL, NULL, NULL, 'neapp_hidecontent_hidelinks_internal'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hidelinks_internal_embeds', \IPS\Settings::i()->neapp_hidecontent_hidelinks_internal_embeds, FALSE, array(), NULL, NULL, NULL, 'neapp_hidecontent_hidelinks_internal_embeds'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hidelinks_external', \IPS\Settings::i()->neapp_hidecontent_hidelinks_external, FALSE, array('togglesOn' => array('neapp_hidecontent_hidelinks_external_nofollow')), NULL, NULL, NULL, 'neapp_hidecontent_hidelinks_external'));
        if (\IPS\Settings::i()->posts_add_nofollow) {
            $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hidelinks_external_nofollow', \IPS\Settings::i()->neapp_hidecontent_hidelinks_external_nofollow, FALSE, array(), NULL, NULL, NULL, 'neapp_hidecontent_hidelinks_external_nofollow'));
        }
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hidementions', \IPS\Settings::i()->neapp_hidecontent_hidementions, FALSE, array(), NULL, NULL, NULL, 'neapp_hidecontent_hidementions'));
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hidelinks_groups', \IPS\Settings::i()->neapp_hidecontent_hidelinks_groups == '*' ? '*' : explode(',', \IPS\Settings::i()->neapp_hidecontent_hidelinks_groups), FALSE, array('options' => \IPS\Member\Group::groups(), 'parse' => 'normal', 'multiple' => TRUE, 'unlimited' => '*', 'unlimitedLang' => 'All Groups'), NULL, NULL, NULL, 'neapp_hidecontent_hidelinks_groups'));
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hidelinks_messagetype', \IPS\Settings::i()->neapp_hidecontent_hidelinks_messagetype, FALSE, array('options' => $messageTypes), NULL, NULL, NULL, 'neapp_hidecontent_hidelinks_messagetype'));
        $form->add(new \IPS\Helpers\Form\Translatable('neapp_hidecontent_hidelinks_text', NULL, FALSE, array('app' => 'nehidecontent', 'key' => 'neapp_hidecontent_hidelinks_text_value', 'editor' => array('app' => 'nehidecontent', 'key' => 'Settings', 'autoSaveKey' => 'neapp_hidecontent_hidelinks_text_value')), NULL, NULL, NULL, 'neapp_hidecontent_hidelinks_text'));
        $form->addTab('neapp_hidecontent_hidequotes_tab');
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hidequotes_groups', \IPS\Settings::i()->neapp_hidecontent_hidequotes_groups == '*' ? '*' : explode(',', \IPS\Settings::i()->neapp_hidecontent_hidequotes_groups), FALSE, array('options' => \IPS\Member\Group::groups(), 'parse' => 'normal', 'multiple' => TRUE, 'unlimited' => '*', 'unlimitedLang' => 'All Groups'), NULL, NULL, NULL, 'neapp_hidecontent_hidequotes_groups'));
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hidequotes_messagetype', \IPS\Settings::i()->neapp_hidecontent_hidequotes_messagetype, FALSE, array('options' => $messageTypes), NULL, NULL, NULL, 'neapp_hidecontent_hidequotes_messagetype'));
        $form->add(new \IPS\Helpers\Form\Translatable('neapp_hidecontent_hidequotes_text', NULL, FALSE, array('app' => 'nehidecontent', 'key' => 'neapp_hidecontent_hidequotes_text_value', 'editor' => array('app' => 'nehidecontent', 'key' => 'Settings', 'autoSaveKey' => 'neapp_hidecontent_hidequotes_text_value')), NULL, NULL, NULL, 'neapp_hidecontent_hidequotes_text'));
        $form->addTab('neapp_hidecontent_hidespoilers_tab');
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hidespoilers_groups', \IPS\Settings::i()->neapp_hidecontent_hidespoilers_groups == '*' ? '*' : explode(',', \IPS\Settings::i()->neapp_hidecontent_hidespoilers_groups), FALSE, array('options' => \IPS\Member\Group::groups(), 'parse' => 'normal', 'multiple' => TRUE, 'unlimited' => '*', 'unlimitedLang' => 'All Groups'), NULL, NULL, NULL, 'neapp_hidecontent_hidespoilers_groups'));
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hidespoilers_messagetype', \IPS\Settings::i()->neapp_hidecontent_hidespoilers_messagetype, FALSE, array('options' => $messageTypes), NULL, NULL, NULL, 'neapp_hidecontent_hidespoilers_messagetype'));
        $form->add(new \IPS\Helpers\Form\Translatable('neapp_hidecontent_hidespoilers_text', NULL, FALSE, array('app' => 'nehidecontent', 'key' => 'neapp_hidecontent_hidespoilers_text_value', 'editor' => array('app' => 'nehidecontent', 'key' => 'Settings', 'autoSaveKey' => 'neapp_hidecontent_hidespoilers_text_value')), NULL, NULL, NULL, 'neapp_hidecontent_hidespoilers_text'));
        $form->addTab('neapp_hidecontent_hidevideos_tab');
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hidevideos_internal', \IPS\Settings::i()->neapp_hidecontent_hidevideos_internal, FALSE, array(), NULL, NULL, NULL, 'neapp_hidecontent_hidevideos_internal'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hidevideos_external', \IPS\Settings::i()->neapp_hidecontent_hidevideos_external, FALSE, array(), NULL, NULL, NULL, 'neapp_hidecontent_hidevideos_external'));
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hidevideos_groups', \IPS\Settings::i()->neapp_hidecontent_hidevideos_groups == '*' ? '*' : explode(',', \IPS\Settings::i()->neapp_hidecontent_hidevideos_groups), FALSE, array('options' => \IPS\Member\Group::groups(), 'parse' => 'normal', 'multiple' => TRUE, 'unlimited' => '*', 'unlimitedLang' => 'All Groups'), NULL, NULL, NULL, 'neapp_hidecontent_hidevideos_groups'));
        $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hidevideos_messagetype', \IPS\Settings::i()->neapp_hidecontent_hidevideos_messagetype, FALSE, array('options' => $messageTypes), NULL, NULL, NULL, 'neapp_hidecontent_hidevideos_messagetype'));
        $form->add(new \IPS\Helpers\Form\Translatable('neapp_hidecontent_hidevideos_text', NULL, FALSE, array('app' => 'nehidecontent', 'key' => 'neapp_hidecontent_hidevideos_text_value', 'editor' => array('app' => 'nehidecontent', 'key' => 'Settings', 'autoSaveKey' => 'neapp_hidecontent_hidevideos_text_value')), NULL, NULL, NULL, 'neapp_hidecontent_hidevideos_text'));
        if (\IPS\Application::load('core')->long_version >= 106138) {
            $form->addTab('neapp_hidecontent_hideaudio_tab');
            $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hideaudio_groups', \IPS\Settings::i()->neapp_hidecontent_hideaudio_groups == '*' ? '*' : explode(',', \IPS\Settings::i()->neapp_hidecontent_hideaudio_groups), FALSE, array('options' => \IPS\Member\Group::groups(), 'parse' => 'normal', 'multiple' => TRUE, 'unlimited' => '*', 'unlimitedLang' => 'All Groups'), NULL, NULL, NULL, 'neapp_hidecontent_hideaudio_groups'));
            $form->add(new \IPS\Helpers\Form\Select('neapp_hidecontent_hideaudio_messagetype', \IPS\Settings::i()->neapp_hidecontent_hideaudio_messagetype, FALSE, array('options' => $messageTypes), NULL, NULL, NULL, 'neapp_hidecontent_hideaudio_messagetype'));
            $form->add(new \IPS\Helpers\Form\Translatable('neapp_hidecontent_hideaudio_text', NULL, FALSE, array('app' => 'nehidecontent', 'key' => 'neapp_hidecontent_hideaudio_text_value', 'editor' => array('app' => 'nehidecontent', 'key' => 'Settings', 'autoSaveKey' => 'neapp_hidecontent_hideaudio_text_value')), NULL, NULL, NULL, 'neapp_hidecontent_hideaudio_text'));
        }
        $form->addTab('neapp_hidecontent_miscellaneous_tab');
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_searchengine', \IPS\Settings::i()->neapp_hidecontent_searchengine, FALSE, array()));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_mergehidemessages', \IPS\Settings::i()->neapp_hidecontent_mergehidemessages, FALSE, array('togglesOn' => array('neapp_hidecontent_mergehidemessages_where')), NULL, NULL, NULL, 'neapp_hidecontent_mergehidemessages'));

        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_imagesinquotes', \IPS\Settings::i()->neapp_hidecontent_imagesinquotes, FALSE, array(), NULL, NULL, NULL, 'neapp_hidecontent_imagesinquotes'));
        //Lightbox stuff
        $form->addHeader('neapp_hidecontent_hideimages_disablelightbox_header');
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hideimages_disablelightbox', \IPS\Settings::i()->neapp_hidecontent_hideimages_disablelightbox, FALSE, array('togglesOn' => array('neapp_hidecontent_hideimages_disablelightbox_login')), NULL, NULL, NULL, 'neapp_hidecontent_hideimages_disablelightbox'));
        $form->add(new \IPS\Helpers\Form\YesNo('neapp_hidecontent_hideimages_disablelightbox_login', \IPS\Settings::i()->neapp_hidecontent_hideimages_disablelightbox_login, FALSE, array(), NULL, NULL, NULL, 'neapp_hidecontent_hideimages_disablelightbox_login'));
        if ($values = $form->values()) {
            $save = array();
            /* Save translatable fields */
            $translatables = array(
                'neapp_hidecontent_hideallcontent_text' => 'neapp_hidecontent_hideallcontent_text_value',
                'neapp_hidecontent_hideattachments_text' => 'neapp_hidecontent_hideattachments_text_value',
                'neapp_hidecontent_hidecode_text' => 'neapp_hidecontent_hidecode_text_value',
                'neapp_hidecontent_hideimages_text' => 'neapp_hidecontent_hideimages_text_value',
                'neapp_hidecontent_hidelinks_text' => 'neapp_hidecontent_hidelinks_text_value',
                'neapp_hidecontent_hidequotes_text' => 'neapp_hidecontent_hidequotes_text_value',
                'neapp_hidecontent_hidespoilers_text' => 'neapp_hidecontent_hidespoilers_text_value',
                'neapp_hidecontent_hidevideos_text' => 'neapp_hidecontent_hidevideos_text_value',
                'neapp_hidecontent_hidesearch_text' => 'neapp_hidecontent_hidesearch_text_value',
                'neapp_hidecontent_hideaudio_text' => 'neapp_hidecontent_hideaudio_text_value'
            );
            foreach ($translatables as $k => $v) {
                if (array_key_exists($k, $values)) {
                    \IPS\Lang::saveCustom('nehidecontent', $v, $values[$k]);
                    unset($values[$k]);
                }
            }

            $form->saveAsSettings(array_merge($form->values(true), $save));
            \IPS\Data\Cache::i()->clearAll();
        }
        //Display the form
        \IPS\Output::i()->title = \IPS\Member::loggedIn()->language()->addToStack('__app_nehidecontent') . ' (v' . \IPS\Application::load('nehidecontent')->version . ') - ' . \IPS\Member::loggedIn()->language()->addToStack('menu__nehidecontent_nehidecontent_nehcsettings');
        \IPS\Output::i()->output = $form;
    }

    // Create new methods with the same name as the 'do' parameter which should execute it
}
